<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("cssfiles/index.css")); ?>">
    <script src="https://kit.fontawesome.com/8331b878b2.js" crossorigin="anonymous"></script>
    <title><?php echo e(env("MINECRAFT_SERVER_NAME")); ?> | Minecraft Server</title>

    <link rel="icon" type="image/x-icon" href="<?php echo e(env("SERVER_IMAGE")); ?>">
</head>
<body>
    <?php echo $__env->make("comps.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="hero_page">
        <div class="card w-100 mb-3 card_info">
            <div class="card-body">
              <h5 class="card-title"><?php echo e(env("MINECRAFT_SERVER_NAME")); ?> Minecraft Server</h5>
              <p class="card-text">It's time to test your skill in our next Hypixel Tournament, Wool Wars 4v4!
                If you don't know about tournaments or the Tournament Hall, or if you'd like to know more about some of the terms in this post, make sure to take a look at the first tournament post.</p>
              <a href="#" class="btn btn-primary"><?php echo e($players); ?> Members Online</a>
              <img src="https://wallpapers.com/images/featured/minecraft-s2kxfahyg30sob8q.jpg" alt="<?php echo e(env("MINECRAFT_SERVER_NAME")); ?>" class="image_minecraft" draggable="false">
            </div>
        </div>
        <?php if(count($events) > 0): ?>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/event/view/<?php echo e($event->user_id); ?>/<?php echo e($event->id); ?>" id="<?php echo e($event->title); ?>">
              <div class="card card_info"
                <?php if(isset($_GET["id"])): ?>
                  <?php if($event->id == $_GET["id"]): ?>
                    style="background-color: rgba(146, 146, 248, 0.3) !important;"
                  <?php endif; ?>
                <?php endif; ?>
                <?php if(session("allContains")): ?>
                  <?php if(in_array($event->id, session("allContains"))): ?>
                    style="background-color: rgba(146, 146, 248, 0.3) !important;"
                  <?php endif; ?>
                <?php endif; ?>
              >
                <div class="card-header">
                  Event <?php echo e($event->title); ?> | <?php echo e($event->version); ?>

                </div>
                <div class="card-body">
                  <blockquote class="blockquote mb-0">
                    <p><?php echo e($event->content); ?></p>
                    <footer class="blockquote-footer">Writed by <cite title="Source Title"><?php echo e(\App\Models\User::where("id", $event->user_id)->first()->username); ?></cite></footer>
                  </blockquote>
                </div>
                <?php if(Auth::user()): ?>
                  <?php if(Auth::user()->id == $event->user_id): ?>
                    <a href="/event/delete/<?php echo e($event->id); ?>">
                      <button style="position: absolute; top: 5px; right: 5px; background-color: rgb(224, 103, 103); color: white; border: none; border-radius: 10px; padding: 10px 30px">Delete</button>
                    </a>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <p style="font-family: Arial; text-align: center; color: white">No events found</p>
        <?php endif; ?>
        <?php
          session()->forget('allContains');
        ?>
    </div>
    <?php if(session("allContains")): ?>
      <?php
        session()->forget("allContains");
      ?>
    <?php endif; ?>
    

    <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset("js/index.js")); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\panel\resources\views/welcome.blade.php ENDPATH**/ ?>