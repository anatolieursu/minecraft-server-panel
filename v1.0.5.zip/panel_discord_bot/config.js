module.exports = {
    panel_url: "http://127.0.0.1:8000",
    bot_token: "MTE2MjgxOTg4NDE0OTkwMzQwMQ.G7ipMS.x_mkk-9w46jQg8Vj_apBRHvLIO6ElXvK0tvAf4",
    events_channel_id: 1162820294264750112
}

// get the panel_url from .env file - APP_URL