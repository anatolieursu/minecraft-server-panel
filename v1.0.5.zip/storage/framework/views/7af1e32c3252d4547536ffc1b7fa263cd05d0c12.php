<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env("MINECRAFT_SERVER_NAME")); ?> Forum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("cssfiles/forum.css")); ?>">
    <script src="https://kit.fontawesome.com/8331b878b2.js" crossorigin="anonymous"></script>

    <link rel="icon" type="image/x-icon" href="<?php echo e(env("SERVER_IMAGE")); ?>">
</head>
<body>
    <?php echo $__env->make("comps.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="forum_page">
        <?php if(count($qas) > 0): ?>
                <?php $__currentLoopData = $qas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/forum/view/<?php echo e($card->user_id); ?>/<?php echo e($card->id); ?>">
                        <div class="card" style="width: 80%; background-color: transparent; border: 1px solid white; color: white; margin: 0 auto; border-radius: 5px; margin-top: 10px; position: relative;">
                            <div class="card-body">
                            <h5 class="card-title"><?php echo e($card->title); ?></h5>
    
                            <div style="display: flex; justify-content: left; align-items: center;">
                                <img style="width: 30px; border-radius: 50%;" class="avatar" src="https://cdn.discordapp.com/avatars/<?php echo e($card->user_id); ?>/<?php echo e($card->avatar); ?>.webp" alt="<?php echo e($card->username); ?>" />
                                <h6 style="margin-left: 10px; color: rgb(166, 166, 166);" class="card-subtitle mb-2"><?php echo e($card->username); ?> | <?php echo e($card->user_id); ?></h6>
                            </div>
    
                            <p class="card-text" style="margin-top: 20px"><?php echo e($card->description); ?></p>
                            <a href="#" class="card-link">QA link</a>
                            <h6 style="color: rgb(166, 166, 166); position: absolute; right: 5px; bottom: 5px;" class="card-subtitle mb-2"><?php echo e($card ->created_at); ?></h6>
                            </div>

                            <?php if(Auth::user()): ?>
                                <?php if(Auth::user()->admin || Auth::user()->id == $card->user_id): ?>
                                    <a href="/forum/delete/<?php echo e($card->id); ?>"><button class="delete_btn">Delete</button></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p style="text-align: center; color: white; font-family: Arial; margin-top: 10px;">No questions found</p>
            <?php endif; ?>
    </div>

    <?php if(count($qas) <= 2): ?>
        <div style="width: 100%; position: absolute; bottom: 0; left: 0">
            <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php else: ?>
        <div style="width: 100%; height: 20px">

        </div>
        <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\panel\panel_website\resources\views/forum.blade.php ENDPATH**/ ?>