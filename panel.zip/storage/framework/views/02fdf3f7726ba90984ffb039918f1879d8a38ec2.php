<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env("MINECRAFT_SERVER_NAME")); ?> Personal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("cssfiles/personal.css")); ?>">
    <script src="https://kit.fontawesome.com/8331b878b2.js" crossorigin="anonymous"></script>

    <link rel="icon" type="image/x-icon" href="<?php echo e(env("SERVER_IMAGE")); ?>">
</head>
<body>
    <?php echo $__env->make("comps.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="personal_page">
        <?php if(count($staff) > 0): ?>
            <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff_categ => $sectionData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="categ">
                    <p class="categ_of_staff"><?php echo e($staff_categ); ?></p>
                    <hr>
                    <?php $__currentLoopData = $sectionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-3" style="width: 100%; color: white; background-color: transparent;  ">
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($data); ?></h5>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p style="color: white; text-align: center">No staff found</p>
        <?php endif; ?>
    </div>

    <?php if($nr < 4): ?>
        <div style="width: 100%; position: absolute; bottom: 0; left: 0">
            <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php else: ?>
        <div style="width: 100%; height: 20px">

        </div>
        <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\panel\resources\views/personal.blade.php ENDPATH**/ ?>