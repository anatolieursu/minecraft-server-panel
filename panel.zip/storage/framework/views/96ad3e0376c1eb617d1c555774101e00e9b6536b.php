<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env("MINECRAFT_SERVER_NAME")); ?> - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("cssfiles/admin.css")); ?>">
    <script src="https://kit.fontawesome.com/8331b878b2.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php echo $__env->make("comps.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin_panel">
        <p class="title" style="margin-top: 10px">Events</p>
        <?php if(count($events) > 0): ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/event/view/<?php echo e($event->user_id); ?>/<?php echo e($event->id); ?>">
                    <div class="card card_info">
                    <div class="card-header">
                        Event <?php echo e($event->title); ?> | <?php echo e($event->version); ?>

                    </div>
                    <div class="card-body">
                        <blockquote class="blockquote mb-0">
                        <p><?php echo e($event->content); ?></p>
                        <footer class="blockquote-footer">Writed by <cite title="Source Title"><?php echo e(\App\Models\User::where("id", $event->user_id)->first()->username); ?></cite></footer>
                        </blockquote>
                    </div>
                    <a href="/event/delete/<?php echo e($event->id); ?>">
                        <button style="position: absolute; top: 5px; right: 5px; background-color: rgb(224, 103, 103); color: white; border: none; border-radius: 10px; padding: 10px 30px">Delete</button>
                    </a>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>
            <p style="text-align: center; color: white; font-family: Arial">No events found</p>
        <?php endif; ?>
        <p class="title">Forums</p>
        <?php if(count($qas) > 0): ?>
            <?php $__currentLoopData = $qas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/forum/view/<?php echo e($card->user_id); ?>/<?php echo e($card->id); ?>">
                    <div class="card" style="width: 100%; background-color: transparent; border: 1px solid white; color: white; margin: 0 auto; border-radius: 5px; margin-top: 10px; position: relative;">
                        <div class="card-body">
                        <h5 class="card-title"><?php echo e($card->title); ?></h5>

                        <div style="display: flex; justify-content: left; align-items: center;">
                            <img style="width: 30px; border-radius: 50%;" class="avatar" src="https://cdn.discordapp.com/avatars/<?php echo e($card->user_id); ?>/<?php echo e($card->avatar); ?>.webp" alt="<?php echo e($card->username); ?>" />
                            <h6 style="margin-left: 10px; color: rgb(166, 166, 166);" class="card-subtitle mb-2"><?php echo e($card->username); ?> | <?php echo e($card->user_id); ?></h6>
                        </div>

                        <p class="card-text" style="margin-top: 20px"><?php echo e($card->description); ?></p>
                        <a href="#" class="card-link">QA link</a>
                        <h6 style="color: rgb(166, 166, 166); position: absolute; right: 5px; bottom: 5px;" class="card-subtitle mb-2"><?php echo e($card ->created_at); ?></h6>
                        </div>

                        <?php if(Auth::user()): ?>
                            <?php if(Auth::user()->admin || Auth::user()->id == $card->user_id): ?>
                                <a href="/forum/delete/<?php echo e($card->id); ?>"><button class="delete_btn">Delete</button></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p style="text-align: center; color: white; font-family: Arial; margin-top: 10px;">No questions found</p>
        <?php endif; ?>
        <p class="title">Staff applications with checking status:</p>
        <?php if(count($applys) > 0): ?>
            <?php $__currentLoopData = $applys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 100%; background-color: transparent; border: 1px solid white; color: white; margin: 0 auto; border-radius: 5px; margin-top: 10px; position: relative;">
                    <div class="card-body">
                    <h5 class="card-title">Reason: <?php echo e($card->reason); ?></h5>

                    <div style="display: flex; justify-content: left; align-items: center;">
                        <img style="width: 30px; border-radius: 50%;" class="avatar" src="https://cdn.discordapp.com/avatars/<?php echo e($card->user_id); ?>/<?php echo e(\App\Models\User::where("id", $card->user_id)->first()->avatar); ?>.webp" alt="<?php echo e($card->username); ?>" />
                        <h6 style="margin-left: 10px; color: rgb(166, 166, 166);" class="card-subtitle mb-2"><?php echo e($card->username); ?> | <?php echo e($card->user_id); ?></h6>
                    </div>

                    <p class="card-text" style="margin-top: 20px">Status: <?php echo e($card->status); ?></p>
                    <form action="/set-status/<?php echo e($card->id); ?>">
                        <p>Set a new status for application</p>
                        <input required style="color: white; padding: 15px 30px; border: 1px solid black; background-color: transparent;" type="text" placeholder="Enter the new status" name="status" >
                        <button type="submit" style="border: none; padding: 15px 30px; border: 1px solid black; background-color: transparent; color: white;">Submit</button>
                    </form>
                    <h6 style="color: rgb(166, 166, 166); position: absolute; right: 5px; bottom: 5px;" class="card-subtitle mb-2"><?php echo e($card ->created_at); ?></h6>
                    </div>

                    <?php if(Auth::user()): ?>
                        <?php if(Auth::user()->admin || Auth::user()->id == $card->user_id): ?>
                            <a href="/forum/delete/<?php echo e($card->id); ?>"><button class="delete_btn">Delete</button></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p style="text-align: center; color: white; font-family: Arial; margin-top: 10px;">No staff applications with checking status found</p>
        <?php endif; ?>
    </div>
    <?php if($nr >= 3): ?>
        <div style="width: 100%; height: 50px">

        </div>
        <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <div style="position: absolute; bottom: 0; width: 100%"> 
            <?php echo $__env->make("comps.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\panel\resources\views/admin.blade.php ENDPATH**/ ?>