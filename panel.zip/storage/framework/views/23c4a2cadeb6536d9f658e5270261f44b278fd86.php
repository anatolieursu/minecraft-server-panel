<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Event <?php echo e($data->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset("cssfiles/event_view.css")); ?>">
    <script src="https://kit.fontawesome.com/8331b878b2.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php echo $__env->make("comps.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="event_view_page">
        <div class="card" style="width: 95%; background-color: transparent; border: 1px solid white; color: white; margin: 0 auto; border-radius: 5px; margin-top: 10px; position: relative;">
            <div class="card-body">
            <h5 class="card-title"><?php echo e($data->title); ?> | Event Version: <?php echo e($data->version); ?></h5>
                <?php
                    $username = \App\Models\User::where("id", $data->user_id)->first()->username;
                ?>
            <div style="display: flex; justify-content: left; align-items: center;">
                <img style="width: 30px; border-radius: 50%;" class="avatar" src="https://cdn.discordapp.com/avatars/<?php echo e($data->user_id); ?>/<?php echo e(\App\Models\User::where("id", $data->user_id)->first()->avatar); ?>.webp" alt="<?php echo e($username); ?>" />
                <h6 style="margin-left: 10px; color: rgb(166, 166, 166);" class="card-subtitle mb-2"><?php echo e($username); ?> | <?php echo e($data->user_id); ?></h6>
            </div>

            <p class="card-text" style="margin-top: 20px"><?php echo e($data->content); ?></p>
            <h6 style="color: rgb(166, 166, 166); position: absolute; right: 5px; bottom: 5px;" class="card-subtitle mb-2"><?php echo e($data ->created_at); ?></h6>
            </div>
            <img src="<?php echo e(str_replace(public_path(), '', $data->image_path)); ?>" alt="<?php echo e($data->title); ?>">
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\panel\resources\views/event_view.blade.php ENDPATH**/ ?>