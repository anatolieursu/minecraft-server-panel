// const navbar = document.getElementById("the_navbar");
// const computedStyle = window.getComputedStyle(navbar);
// console.log(computedStyle.height);
